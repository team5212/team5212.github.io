<?php
require('./blog/wp-blog-header.php');
?>
<!DOCTYPE HTML>
<html lang="en">
   <head>
      <meta charset="UTF-8">
      <title>Team 5212</title>
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen"/>
      <link type="text/css" rel="stylesheet" href="css/5212.css" />
      <link rel="stylesheet" type="text/css" href="css/component.css" />
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
   </head>
   <body>
      <script type="text/javascript" src="js/jquery-2.1.1.min.js"></script>
      <script type="text/javascript" src="js/materialize.min.js"></script>
      <script type="text/javascript" src="js/jquery.scrollfire.min.js"></script>
      <script type="text/javascript" src="js/5212.js"></script>
      <script src="js/modernizr.custom.js"></script>
      <div class="navbar-fixed">
         <nav>
            <div class="nav-wrapper green lighten-2">
               <a href="javascript:void(0);" class="brand-logo"><span class="hide-on-med-and-down">&nbsp;&nbsp;</span>Team 5212</a>

               <a href="#" data-activates="nav-mobile-side" class="button-collapse"><i class="material-icons">menu</i></a>
               <ul id="nav-mobile" class="right hide-on-med-and-down">
                  <li class="about nav"><a href="javascript:void(0);" onclick="javascript:scrollTo('about')">About</a></li>
                  <li class="updates nav"><a href="javascript:void(0);" onclick="javascript:scrollTo('updates')">News</a></li>
                  <li class="outreach nav"><a href="javascript:void(0);" onclick="javascript:scrollTo('outreach')">Outreach</a></li>
                  <li class="members nav"><a href="javascript:void(0);" onclick="javascript:scrollTo('members')">Members</a></li>
                  <li><a class="waves-effect waves-light btn blue" href="http://www.gofundme.com/tamsformers-robotics-team-2016">donate</a></li>
               </ul>
            </div>
         </nav>

      </div>
      <ul id="nav-mobile-side" class="side-nav">
         <li class="about nav"><a href="javascript:void(0);" onclick="javascript:scrollTo('about')">About</a></li>
         <li class="updates nav"><a href="javascript:void(0);" onclick="javascript:scrollTo('updates')">News</a></li>
         <li class="outreach nav"><a href="javascript:void(0);" onclick="javascript:scrollTo('outreach')">Outreach</a></li>
         <li class="members nav"><a href="javascript:void(0);" onclick="javascript:scrollTo('members')">Members</a></li>
         <li><a class="waves-effect waves-light btn blue" href="http://www.gofundme.com/tamsformers-robotics-team-2016">donate</a></li>
      </ul>

      <div>
         <div style="position:relative">
            <img src="img/robot.jpg" alt="robot image" style="width: 100%">

            <h2 class="null header image-title">TAMSformers 2017</h2>

            <div class="all-badges">
               <div class="badge-container" onclick='javascript:scrollTo("updates")'>
                  <div class="badge unhovered" style="top:40%; left:40%">
                     <div class="badgetitle">Recent Updates</div>
                  </div>
                  <div class="badge hovered" style="opacity:0; top:40%; left:40%">
                     <div class="badgetitle" style="color:#000; top: 85px; font-size:13px">Stay informed on our progress</div>
                  </div>
               </div>
               <div class="badge-container" onclick='javascript:scrollTo("about")'>
                  <div class="badge unhovered" style="top:60%; left:60%">
                     <div class="badgetitle">About</div>
                  </div>
                  <div class="badge hovered" style="opacity:0; top:60%; left:60%">
                     <div class="badgetitle" style="color:#000; top: 83px; font-size:13px">Learn more about our team<br />in general</div>
                  </div>
               </div>
               <div class="badge-container" onclick='javascript:scrollTo("outreach")'>
                  <div class="badge unhovered" style="top:20%; left:20%">
                     <div class="badgetitle">Outreach</div>
                  </div>
                  <div class="badge hovered" style="opacity:0; top:20%; left:20%">
                     <div class="badgetitle" style="color:#000; top: 80px; font-size:13px">Learn more about our<br />community outreach endeavors</div>
                  </div>
               </div>
               <div class="badge-container" onclick='javascript:scrollTo("members")'>
                  <div class="badge unhovered" style="top:20%; left:69%">
                     <div class="badgetitle">Members</div>
                  </div>
                  <div class="badge hovered" style="opacity:0; top:20%; left:69%">
                     <div class="badgetitle" style="color:#000; top: 85px; font-size:13px">View our member photos</div>
                  </div>
               </div>
               <div onclick="javascript:window.location='http://www.gofundme.com/tamsformers-robotics-team-2016'" class="badge-container">
                  <div class="badge unhovered" style="top:60%; left:11%">
                     <div class="badgetitle">Donate</div>
                  </div>
                  <div class="badge hovered" style="opacity:0; top:60%; left:11%">
                     <div class="badgetitle" style="color:#000; top: 85px; font-size:13px">Contribute to our team</div>
                  </div>
               </div>
            </div>
         </div>

      </div>
      <div class="container">
         <h2 class="about header">About</h2>
         <p class="flow-text">
            Our team is an extracurricular group of students. We all go to the Texas Academy of Mathematics and Science. TAMS is a unique residential program for high school-aged Texas students who are high achievers and interested in mathematics and science. While living in McConnell Hall, students in this two-year program complete a rigorous academic curriculum of college coursework at the University of North Texas (UNT). Instruction is by regular university faculty. There are no high school courses taught, but students enjoy many of the activities of high school and the company of age mates who are intellectual peers.
         </p>
         <p class="flow-text">
            Due to our unique situation, we are a completely student-led team, with very little help from adults. We not only coordinate everything having to do with the actual competition such as designing and building the robot, but we also manage our own finances and do everything else that running a team requires.
         </p>
         <h2 class="updates header">News</h2>
         <ul class="cbp_tmtimeline">
            <?php
               $posts = get_posts('numberposts=5&order=DSC&orderby=date');
               foreach ($posts as $post) : setup_postdata( $post ); ?>
				<li>
					<time class="cbp_tmtime"><span><?php the_date('F d'); ?></span></time>
               <a href="<?php the_permalink(); ?>">
   					<div class="cbp_tmlabel">
                     <div class="cbp_title">
      						<h2><?php the_title(); ?></h2>
                        <div><?php the_time(); ?></div>
                     </div>
   						<p><?php
                     if ( has_post_thumbnail() ) {
                         the_post_thumbnail();
                     }
                     ?><?php the_excerpt(); ?></p>
   					</div>
               </a>
				</li>
            <?php endforeach; ?>
			</ul>
         <h2 class="outreach header">Outreach</h2>
         <p class="flow-text">
            Our robotics team greatly prioritizes integration with the district and regional community. As part of a school of students that have shown excellence and interest in the STEM field, we are invested in much more than engineering and science itself. For many of our teammates, the club is a chance to connect and help students explore STEM and truly have a chance to learn from it. For many of us, opportunities at our previous institutions for STEM were limited, if at all present. Now, we have the opportunity and obligation to educate, inspire and assist the rising generation of students in engineering.
         </p>
      </div>
      <div class="parallax-container">
         <div class="parallax"><img src="img/outreach.jpg" style="width:100%" alt="A team member demonstrates our 2016 competition robot at our second annual Science Adventures summer camp." /></div>
      </div>
      <div class="container">
         <span class="img-caption">A team member demonstrates our 2016 competition robot at our second annual Science Adventures summer camp.</span>
         <p class="flow-text">
            Unfortunately, there are a few local schools that cannot afford extra science experiments in the curriculum. The Junior Engineering Technical Society or JETS club (the parent organization of TAMSformers) at TAMS, has a program to create and send STEM boxes to local elementary schools. These boxes contain small, informative experiments that children conduct. Each box caters to a specific scientific law or theory or phenomenon and comes with well-written explanations and pictures, so students can understand the science behind the principle being demonstrated. The boxes are also synchronized with each school's curriculum. Through coordinating with teachers, we maximize the students' knowledge about a subject: first in class, and then in firsthand experiments.
            <br /> <br />We have been representing the TAMS program at many different events in the DFW region. We were at the Earth Day Event in April 2016, ...
         </p>
         <h2 class="members header">Members</h2>
         <div style="text-align:center">
            <div style="text-align:center" class="member-section-label">Execs</div>
            <div class="members-container">
               <div>
                  <img class="img-circle exec-img" alt="member photo" src="photos/andrew.jpg">
                  <div style="text-align:center" class="member-label">Andrew</div>
                  <div style="text-align:center" class="member-title">Engineering lead</div>
               </div>
               <div>
                  <img class="img-circle exec-img" alt="member photo" src="photos/christian.jpg">
                  <div style="text-align:center" class="member-label">Christian</div>
                  <div style="text-align:center" class="member-title">Electrical lead</div>
               </div>
               <div>
                  <img class="img-circle exec-img" alt="member photo" src="photos/david.jpg">
                  <div style="text-align:center" class="member-label">David</div>
                  <div style="text-align:center" class="member-title">Team captain</div>
               </div>
               <div>
                  <img class="img-circle exec-img" alt="member photo" src="photos/emelyne.jpg">
                  <div style="text-align:center" class="member-label">Emelyne</div>
                  <div style="text-align:center" class="member-title">Volunteering lead</div>
               </div>
               <div>
                  <img class="img-circle exec-img" alt="member photo" src="photos/ryland.jpg">
                  <div style="text-align:center" class="member-label">Ryland</div>
                  <div style="text-align:center" class="member-title">Programming lead</div>
               </div>
               <div>
                  <img class="img-circle exec-img" alt="member photo" src="photos/shelby.jpg">
                  <div style="text-align:center" class="member-label">Shelby</div>
                  <div style="text-align:center" class="member-title">Business lead</div>
               </div>
            </div>
            <div style="text-align:center" class="member-section-label">Other Members</div>
            <div class="members-container">
               <div>
                  <img class="img-circle" alt="member photo" src="photos/alex.jpg">
                  <div style="text-align:center" class="member-label">Alex</div>
                  <div style="text-align:center" class="member-title">&nbsp;</div>
               </div>
               <div>
                  <img class="img-circle" alt="member photo" src="photos/alyssa.jpg">
                  <div style="text-align:center" class="member-label">Alyssa</div>
                  <div style="text-align:center" class="member-title">&nbsp;</div>
               </div>
               <div>
                  <img class="img-circle" alt="member photo" src="photos/andrew1.jpg">
                  <div style="text-align:center" class="member-label">Andrew</div>
                  <div style="text-align:center" class="member-title">&nbsp;</div>
               </div>
               <div>
                  <img class="img-circle" alt="member photo" src="photos/arko.jpg">
                  <div style="text-align:center" class="member-label">Arko</div>
                  <div style="text-align:center" class="member-title">&nbsp;</div>
               </div>
               <div>
                  <img class="img-circle" alt="member photo" src="photos/cedric.jpg">
                  <div style="text-align:center" class="member-label">Cedric</div>
                  <div style="text-align:center" class="member-title">&nbsp;</div>
               </div>
               <div>
                  <img class="img-circle" alt="member photo" src="photos/daniel.jpg">
                  <div style="text-align:center" class="member-label">Daniel</div>
                  <div style="text-align:center" class="member-title">&nbsp;</div>
               </div>
               <div>
                  <img class="img-circle" alt="member photo" src="photos/garrett.jpg">
                  <div style="text-align:center" class="member-label">Garrett</div>
                  <div style="text-align:center" class="member-title">Webmaster</div>
               </div>
               <div>
                  <img class="img-circle" alt="member photo" src="photos/jai.jpg">
                  <div style="text-align:center" class="member-label">Jai</div>
                  <div style="text-align:center" class="member-title">&nbsp;</div>
               </div>
               <div>
                  <img class="img-circle" alt="member photo" src="photos/jenya.jpg">
                  <div style="text-align:center" class="member-label">Jenya</div>
                  <div style="text-align:center" class="member-title">&nbsp;</div>
               </div>
               <div>
                  <img class="img-circle" alt="member photo" src="photos/john.jpg">
                  <div style="text-align:center" class="member-label">John</div>
                  <div style="text-align:center" class="member-title">&nbsp;</div>
               </div>
               <div>
                  <img class="img-circle exec-img" alt="member photo" src="photos/josiah.jpg">
                  <div style="text-align:center" class="member-label">Josiah</div>
                  <div style="text-align:center" class="member-title">&nbsp;</div>
               </div>
               <div>
                  <img class="img-circle" alt="member photo" src="photos/kavya.jpg">
                  <div style="text-align:center" class="member-label">Kavya</div>
                  <div style="text-align:center" class="member-title">&nbsp;</div>
               </div>
               <div>
                  <img class="img-circle" alt="member photo" src="photos/kj.jpg">
                  <div style="text-align:center" class="member-label">KJ</div>
                  <div style="text-align:center" class="member-title">&nbsp;</div>
               </div>
               <div>
                  <img class="img-circle" alt="member photo" src="photos/lan.jpg">
                  <div style="text-align:center" class="member-label">Lan</div>
                  <div style="text-align:center" class="member-title">&nbsp;</div>
               </div>
               <div>
                  <img class="img-circle" alt="member photo" src="photos/maurice.jpg">
                  <div style="text-align:center" class="member-label">Maurice</div>
                  <div style="text-align:center" class="member-title">&nbsp;</div>
               </div>
               <div>
                  <img class="img-circle" alt="member photo" src="photos/michelle.jpg">
                  <div style="text-align:center" class="member-label">Michelle</div>
                  <div style="text-align:center" class="member-title">&nbsp;</div>
               </div>
               <div>
                  <img class="img-circle" alt="member photo" src="photos/morgan.jpg">
                  <div style="text-align:center" class="member-label">Morgan</div>
                  <div style="text-align:center" class="member-title">&nbsp;</div>
               </div>
               <div>
                  <img class="img-circle" alt="member photo" src="photos/nathan.jpg">
                  <div style="text-align:center" class="member-label">Nathan</div>
                  <div style="text-align:center" class="member-title">&nbsp;</div>
               </div>
               <div>
                  <img class="img-circle" alt="member photo" src="photos/rasna.jpg">
                  <div style="text-align:center" class="member-label">Rasna</div>
                  <div style="text-align:center" class="member-title">&nbsp;</div>
               </div>
               <div>
                  <img class="img-circle" alt="member photo" src="photos/ryan.jpg">
                  <div style="text-align:center" class="member-label">Ryan</div>
                  <div style="text-align:center" class="member-title">&nbsp;</div>
               </div>
               <div>
                  <img class="img-circle" alt="member photo" src="photos/sven.jpg">
                  <div style="text-align:center" class="member-label">Sven</div>
                  <div style="text-align:center" class="member-title">&nbsp;</div>
               </div>
               <div>
                  <img class="img-circle" alt="member photo" src="photos/tobias.jpg">
                  <div style="text-align:center" class="member-label">Tobias</div>
                  <div style="text-align:center" class="member-title">&nbsp;</div>
               </div>
            </div>
         </div>
      </div>

      <div style="text-align:center"><a class="waves-effect waves-light btn-large blue darken-1" href="http://www.gofundme.com/tamsformers-robotics-team-2016">Click here to support us</a></div>
      <br />
      <br />
      <div class="shade">
         <div class="real-shade"><i class="material-icons close-button">close</i></div>
      </div>
   </body>
</html>
